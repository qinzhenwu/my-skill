---
name: nfvo-summary-config-generator
description: 为 NFVO 数据汇总任务生成配置 SQL 脚本。当用户需要创建新的汇总任务配置、添加汇总任务、或生成配置 SQL 时使用此 skill。用户只需提供汇总任务的基本信息（名称、编码、数据源、字段配置等），skill 将自动生成完整的 INSERT SQL 脚本。
---

# NFVO 汇总配置 SQL 生成器

为 PowerJob Worker 数据汇总任务生成完整的配置 SQL 脚本。

## 输入信息收集

请用户提供以下必要信息：

| 项目 | 说明 | 示例 |
|------|------|------|
| 汇总任务名称 | 配置名称 | 网间话务IBCF省5分钟性能数据 |
| 编码 | config_code | IBCF_PROVINCE_5_PERFORMANCE_SUM |
| 汇总类型 | summary_type | hour/day/month/minute/fiveMinute |
| 专业类型 | specialty | IBCF |
| 数据源 | source_db | clickhouse 或其他数据库编码 |
| 入库数据库 | to_db_code | 通常与 source_db 相同 |
| 结果表名 | result_table_name | pm_ibck_5_province |
| CK本地表 | ck_local_table | 仅 ClickHouse 数据源需要 |
| simple_flag | 简单汇总标记 | 1（简单）或 0（多阶段） |
| 延迟分钟数 | delay_minute | 如 60 |
| 基础查询 SQL | base_sql | 使用 ${startTime} 占位符 |
| field_config_type_id | 字段配置类型 ID | 如 2079 |
| 字段列表 | 字段配置 | 字段名、类型、描述 |
| 字段 ID 起始值 | 字段配置 ID | 如 145000417 |
| **批量查询 SQL**（可选） | field_sql | 多个字段共用一条 SQL 批量查询，减少查询次数 |

## 字段查询方式

支持两种字段查询方式：

### 方式一：单独查询（简单场景）

每个字段使用独立的 `result_field_sql_expression` 查询：
- 适用于字段查询逻辑简单、各字段独立查询的场景
- 字段配置中设置 `result_field_sql_expression`

### 方式二：批量查询（复杂场景）

多个字段共用一条 SQL 批量查询，通过 `t_power_job_field_sql` 配置：
- 适用于多个字段可从一个查询结果中获取的场景
- 减少查询次数，提高性能
- 需要额外配置 `t_power_job_field_sql` 表
- 字段配置中设置 `field_sql_id` 关联批量查询 SQL

## SQL 生成规则

### 1. 基础 SQL 配置 (t_power_job_base_sql)

- `id`: **必填** - 需先查询现有最大ID：`SELECT MAX(id) FROM t_power_job_base_sql`，使用结果+1
- `uid`: 使用描述性命名，建议格式为 `{编码}_SQL`
- `base_sql`: 用户提供的查询 SQL
- `remark`: 配置说明，格式为 `{任务名称}基础查询SQL`

### 2. 汇总基础配置 (t_power_job_base_config)

必需字段：
- `config_name`: 汇总任务名称
- `config_code`: 配置编码
- `field_config_type_id`: 字段配置类型 ID
- `summary_type`: 汇总类型
- `specialty`: 专业类型
- `base_sql_uid`: 关联到 t_power_job_base_sql 的 uid
- `result_table_name`: 结果表名
- `source_db`: 数据源编码
- `to_db_code`: 入库数据库编码
- `ck_local_table`: 仅当 source_db='clickhouse' 时添加
- `delay_minute`: 延迟执行分钟数
- `simple_flag`: 简单汇总标记

### 3. 字段配置 (t_power_job_field_config)

每个字段生成一条 INSERT：
- `id`: 从起始值开始递增
- `field_config_type`: 与 field_config_type_id 相同
- `result_field_code`: 字段编码（英文）
- `result_field_name`: 字段名称（中文）
- `result_field_type`: 字段类型
- `field_from_type`: 默认使用 'index'
- `result_field_sql_expression`: 字段查询 SQL 表达式（单独查询方式）
- `field_sql_id`: 批量查询 SQL 配置 ID（批量查询方式）
- `load_to_db`: 默认为 1

### 4. 批量查询 SQL 配置 (t_power_job_field_sql) - 可选

当使用批量查询方式时，需要配置此表：

- `id`: **必填** - 需先查询现有最大ID：`SELECT MAX(id) FROM t_power_job_field_sql`，使用结果+1
- `sql_script`: 批量查询 SQL，使用 `${xxx}` 占位符引用基础查询结果中的字段
- `remark`: 备注说明

**批量查询 SQL 示例：**
```sql
-- 批量查询多个指标字段
SELECT field1, field2, field3 FROM metric_table 
WHERE device_id = '${device_id}' AND time = '${data_time}'
```

**字段配置关联批量查询：**
- 使用批量查询的字段：设置 `field_sql_id` 关联 `t_power_job_field_sql.id`
- 不使用 `result_field_sql_expression`（由批量查询 SQL 获取）

## 批量查询配置流程

当需要使用批量查询时，按以下步骤配置：

```sql
-- =============================================
-- 步骤0: 插入批量查询SQL配置（可选，批量查询场景）
-- =============================================
-- 先查询现有最大ID
SELECT MAX(id) FROM t_power_job_field_sql;
-- 使用查询结果+1作为新记录的ID
INSERT INTO t_power_job_field_sql (id, sql_script, remark)
VALUES (
    {field_sql_max_id + 1},
    'SELECT field1, field2 FROM table WHERE id = ''${id}''',
    '{任务名称}字段批量查询SQL'
);

-- 获取刚插入的 field_sql_id（用于后续字段配置）
SELECT id FROM t_power_job_field_sql WHERE remark = '{任务名称}字段批量查询SQL';
```

-- =============================================
-- 步骤3: 插入字段配置（使用批量查询）
-- =============================================
-- 使用批量查询的字段：设置 field_sql_id，不设置 result_field_sql_expression
INSERT INTO t_power_job_field_config (id, field_config_type, result_field_code, result_field_name, result_field_type, field_from_type, field_sql_id, load_to_db) 
VALUES ({id}, {field_config_type_id}, '{field_code}', '{field_name}', '{field_type}', 'index', {field_sql_id}, 1);

-- 单独查询的字段：设置 result_field_sql_expression，不设置 field_sql_id
INSERT INTO t_power_job_field_config (id, field_config_type, result_field_code, result_field_name, result_field_type, field_from_type, result_field_sql_expression, load_to_db) 
VALUES ({id}, {field_config_type_id}, '{field_code}', '{field_name}', '{field_type}', 'index', 'select ''${field_code}'' {field_code}', 1);
```

**重要：入库字段配置必须包含时间字段**

程序会根据时间字段删除旧数据再插入新数据，不同数据源要求不同：

| 入库数据源 (to_db_code) | 必需时间字段 | 说明 |
|-------------------------|--------------|------|
| clickhouse | `start_time` | 仅需 start_time |
| mysql / tidb | `start_time`, `end_time` | 需要两个时间字段 |

**时间字段配置示例：**

ClickHouse 入库：
```sql
-- start_time 字段
INSERT INTO t_power_job_field_config (id, field_config_type, result_field_code, result_field_name, result_field_type, field_from_type, result_field_sql_expression, load_to_db) 
VALUES ({id}, {field_config_type_id}, 'start_time', '开始时间', 'datetime', 'index', 'select ''${startTime}'' start_time', 1);
```

MySQL/TiDB 入库：
```sql
-- start_time 字段
INSERT INTO t_power_job_field_config (id, field_config_type, result_field_code, result_field_name, result_field_type, field_from_type, result_field_sql_expression, load_to_db) 
VALUES ({id}, {field_config_type_id}, 'start_time', '开始时间', 'datetime', 'index', 'select ''${startTime}'' start_time', 1);

-- end_time 字段
INSERT INTO t_power_job_field_config (id, field_config_type, result_field_code, result_field_name, result_field_type, field_from_type, result_field_sql_expression, load_to_db) 
VALUES ({id+1}, {field_config_type_id}, 'end_time', '结束时间', 'datetime', 'index', 'select ''${endTime}'' end_time', 1);
```

## 输出格式模板

```sql
-- =============================================
-- {汇总任务名称} 配置
-- 编码: {config_code}
-- =============================================

-- =============================================
-- 步骤1: 插入基础查询SQL配置
-- =============================================
-- 先查询现有最大ID
SELECT MAX(id) FROM t_power_job_base_sql;
-- 使用查询结果+1作为新记录的ID（假设查询结果为 base_sql_max_id）
INSERT INTO t_power_job_base_sql (id, uid, base_sql, remark)
VALUES (
    base_sql_max_id + 1,
    '{base_sql_uid}',
    '{base_sql}',
    '{任务名称}基础查询SQL'
);

-- =============================================
-- 步骤2: 插入汇总基础配置
-- =============================================
INSERT INTO t_power_job_base_config (
    config_name,
    config_code,
    field_config_type_id,
    summary_type,
    specialty,
    base_sql_uid,
    result_table_name,
    source_db,
    to_db_code,
    {ck_local_table字段，仅ClickHouse}
    delay_minute,
    simple_flag
)
VALUES (
    '{config_name}',
    '{config_code}',
    {field_config_type_id},
    '{summary_type}',
    '{specialty}',
    '{base_sql_uid}',
    '{result_table_name}',
    '{source_db}',
    '{to_db_code}',
    '{ck_local_table}',  -- 仅当数据源为ClickHouse时添加
    {delay_minute},
    {simple_flag}
);

-- =============================================
-- 步骤3: 插入字段配置
-- =============================================
INSERT INTO t_power_job_field_config (id, field_config_type, result_field_code, result_field_name, result_field_type, field_from_type, result_field_sql_expression, load_to_db) VALUES ({id}, {field_config_type_id}, '{field_code}', '{field_name}', '{field_type}', 'index', 'select ''${field_code}'' ${field_code}', 1);
-- ... 为每个字段生成一条 INSERT

-- =============================================
-- 验证查询
-- =============================================
SELECT * FROM t_power_job_base_config WHERE config_code = '{config_code}';
SELECT * FROM t_power_job_field_config WHERE field_config_type = {field_config_type_id};
```

## ClickHouse SQL 注意事项

当数据源为 ClickHouse 时，查询 SQL 需要注意类型一致性：

- 使用 `toFloat64()` 包装数值表达式确保类型一致
- 数值常量使用小数形式，如 `100.0` 而非 `100`
- 示例错误：`if(sum(attsession)=0, 100, round(...))` - 两分支类型不同
- 正确写法：`if(sum(attsession) = 0, 100.0, toFloat64(sum(...)) / toFloat64(sum(...)) * 100.0)`

## 参考文档

完整的配置表结构请参阅 `references/config-schema.md`。