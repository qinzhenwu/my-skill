# NFVO 汇总配置表结构

## 表关联关系

```
tb_data_source_config (数据源)
        ↓ source_db / to_db_code
t_power_job_base_config (基础配置)
        ↓ base_sql_uid
t_power_job_base_sql (SQL配置)
        ↓ field_config_type_id
t_power_job_field_config (字段配置)
        ↓ field_sql_id (可选，批量查询场景)
t_power_job_field_sql (字段批量查询SQL配置)
```

## t_power_job_base_sql 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| id | bigint | **必填** - 主键ID，需手动指定（查询现有最大值+1） |
| uid | varchar | SQL 配置唯一标识 |
| base_sql | text | 查询 SQL，使用 ${startTime} 等占位符 |
| remark | varchar | 备注说明 |

## t_power_job_base_config 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| config_name | varchar | 配置名称（中文） |
| config_code | varchar | 配置编码（英文，唯一） |
| field_config_type_id | int | 字段配置类型 ID |
| summary_type | varchar | 汇总类型：hour/day/month/minute/fiveMinute |
| specialty | varchar | 专业类型 |
| base_sql_uid | varchar | 关联 t_power_job_base_sql 的 uid |
| result_table_name | varchar | 结果表名 |
| source_db | varchar | 数据源编码 |
| to_db_code | varchar | 入库数据库编码 |
| ck_local_table | varchar | ClickHouse 本地表名（仅 CK 数据源） |
| delay_minute | int | 延迟执行分钟数 |
| simple_flag | int | 简单汇总标记：1=简单，0=多阶段 |

## t_power_job_field_config 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| id | bigint | 字段配置 ID（需手动指定） |
| field_config_type | int | 字段配置类型（与 field_config_type_id 相同） |
| result_field_code | varchar | 结果字段编码（英文） |
| result_field_name | varchar | 结果字段名称（中文） |
| result_field_type | varchar | 结果字段类型 |
| field_from_type | varchar | 字段来源类型：basic（直接）或 index（需额外查询） |
| result_field_sql_expression | varchar | 单独查询 SQL 表达式（单独查询方式使用） |
| field_sql_id | int | 批量查询 SQL 配置 ID（批量查询方式使用） |
| load_to_db | int | 是否入库：1 |

## t_power_job_field_sql 字段（批量查询场景）

| 字段 | 类型 | 说明 |
|------|------|------|
| id | bigint | **必填** - 批量查询 SQL 配置 ID，需手动指定（查询现有最大值+1） |
| sql_script | text | 批量查询 SQL，使用 `${xxx}` 引用基础查询字段 |
| remark | text | 备注说明 |

## 入库时间字段要求

| 入库数据源 | 必需时间字段 | 说明 |
|------------|--------------|------|
| clickhouse | `start_time` | 仅需 start_time |
| mysql / tidb | `start_time`, `end_time` | 需要两个时间字段 |

程序根据时间字段删除旧数据再插入新数据。

## SQL 时间占位符

| 占位符 | 说明 | 使用场景 |
|--------|------|----------|
| `${startTime}` | 汇总开始时间 | WHERE 条件过滤 |
| `${endTime}` | 汇总结束时间 | WHERE 条件过滤 |
| `${timeIndex}` | 时间索引 | 用于结果表索引字段 |
| `${batchCode}` | 批次编码 | 用于批次标识 |

## 汇总类型说明

| 类型 | 说明 | 时间范围计算 |
|------|------|--------------|
| hour | 小时汇总 | 上一个完整小时 |
| day | 日汇总 | 上一个完整天 |
| month | 月汇总 | 上一个完整月 |
| minute | 15分钟汇总 | 上一个15分钟区间 |
| fiveMinute | 5分钟汇总 | 上一个5分钟区间 |